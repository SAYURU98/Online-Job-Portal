<?php
include_once('db.php');

if(isset($_POST['submit'])){
    if(!empty($_POST['email']) && !empty($_POST['firstname']) && !empty($_POST['lastname']) && !empty($_POST['phonenumber']) && !empty($_POST['birthday']) && !empty($_POST['district']) && !empty($_POST['educationalq'])){

    
        $id = $_POST['id'];
        //$email = $_POST['email'];
        //$firstname = $_POST['firstname'];
        //$lastname = $_POST['lastname'];
        //$phonenumber = $_POST['phonenumber'];
        //$birthday = $_POST['birthday'];
        //$district = $_POST['district'];
       // $educationalq = $_POST['educationalq'];

        $query = "update useracc SET email= '$_POST[email]', firstname= '$_POST[firstname]', lastname= '$_POST[lastname]', phonenumber= '$_POST[phonenumber]', birthday= '$_POST[birthday]', district= '$_POST[district]', educationalq= '$_POST[educationalq]' where id=$_POST[id]";
        $executequery = mysqli_query($conn, $query);

        if($executequery){
            echo "Form Sumbitted Successfully";
        }
        else{
            echo "Form not submitted";
        }
    }
    else{
        echo "all Data Insertion Successfull";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DreamJobs.lk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>
<body>
    <div class="head">
        <div class="navbar">
            <h1>DreamJobs.lk</h1>
            <ul>
                <li><a href="#">Home <i class="fas fa-ad"></i></a></li>
                <li><a href="#">Post a Job <i class="fas fa-cloud-upload-alt"></i></a></li>
                <li><a href="#">Find a Job <i class="fas fa-search"></i></a></li>
                <li><a href="#">Sign up <i class = "fas fa-search"></i></a></li>
                <li><a href="#">Sign in <i class = "fas fa-search"></i></a></li>
                <li><button type="button" class="btn btn-primary">Submit Your CV</button></li>
            </ul>
        </div>
    </div>
    <br>
    <br>
       <hr>
    <div class = "row">
    <div class="form">

        <div class="info">
            <h3>Information</h3>
            <div class="info_data">
                <form action="useredit.php" method="post">
                    <?php 
                    $query="select * from useracc";
                    $result = mysqli_query($conn, $query);
                    while($rows=mysqli_fetch_assoc($result))
                        {
                            ?>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" name="email" value="<?php echo $rows['email'];?>">
                    </div>
                    <br>

                    <div class="form-group">
                        <label for="firstname">First Name</label>
                        <input type="text" class="form-control" name="firstname" value="<?php echo $rows['firstname'];?>">
                    </div>
                    <br>

                    <div class="form-group">
                        <label for="lastname">last Name</label>
                        <input type="text" class="form-control" name="lastname" value="<?php echo $rows['lastname'];?>">
                    </div>
                     <br>

                    <div class="form-group">
                        <label for="phonenumber">Phone Number</label>
                        <input type="text" class="form-control" name="phonenumber" value="<?php echo $rows['phonenumber'];?>">
                    </div>
                    <br>

                    <div class="form-group">
                        <label for="birthday">Birthday</label>
                        <input type="text" class="form-control" name="birthday" value="<?php echo $rows['birthday'];?>">
                    </div>
                    <br>

                    <div class="form-group">
                        <label for="district">District</label>
                        <input type="text" class="form-control" name="district" value="<?php echo $rows['district'];?>">
                    </div>
                    <br>

                    <div class="form-group">
                        <label for="educationalq">Educational Qualitifications</label>
                        <input type="text" class="form-control" name="educationalq" value="<?php echo $rows['educationalq'];?>">
                    </div>
                    <input type="hidden" value="<?php echo $rows['id']; ?>" name="id">
                    <br>
                    <input type="submit" name="submit" value="Submit">  
                    <?php } ?>
                </form>
             
                <br>
              
            </div>
        </div> 
    </div>
    </div>
  
 
    <footer class="container">
        <div class="box-1">
            <h5>About us</h5>
            <br>
            <br>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At consectetur architecto blanditiis cumque, nulla
                libero nesciunt exercitationem totam quibusdam provident unde eius dignissimos tempora in dolores voluptates.
                Velit, beatae debitis.</p>
        </div>
        <div class="box-2">
            <h5>Site Map</h5>
            <br>
            <br>
            <ul>
                <li>Home</li><br>
                <li>Post a Job</li><br>
                <li>Find a Job</li><br>
                <li>Categories</li><br>
                <li>Signup</li><br>
                <li>Signin</li><br>
                <li>Contact Us</li><br>
                <li>About Us</li><br>
                <li>Submit CV</li><br>
                <li>Your Account</li><br>
            </ul>
        </div>
        <div class="box-3">
            <h5>Follow Us</h5>
            <br>
            <br>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At consectetur architecto blanditiis cumque, nulla
                libero nesciunt exercitationem totam quibusdam provident unde eius dignissimos tempora in dolores voluptates.
                Velit, beatae debitis.</p>
        </div>
        <div class="box-4">
            <h5>Contact us</h5>
            <br>
            <br>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At consectetur architecto blanditiis cumque, nulla
                libero nesciunt exercitationem totam quibusdam provident unde eius dignissimos tempora in dolores voluptates.
                Velit, beatae debitis.</p>
        </div>
    </div>
</footer>
</html>        