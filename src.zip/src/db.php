<?php
$host = "localhost";
$user = "root";
$database = "onlinejobportal";
$password  = ""; 

if($conn = new mysqli($host, $user, $password, $database)){

}else{
    echo 'Error DataBase Connection';
    exit;
}
