<!DOCTYPE html>
<html>
<!--header section; do not edit-->
<head>
      <script src="https://kit.fontawesome.com/350c24570c.js" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/submitcv.css">
    <script src="js/submitcv.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <title> DreamJobs </title>
</head>

<body>
<header>
  <div class="container1">
     <h1 style="font-size:40px; font-family:courier,monospace; text-align:left; padding-left:45px; float:left;">DreamJobs <i class="fas fa-anchor"></i></h1>

     <nav>

     <ul class="menu">
     <li class="menu"><a href="DreamJobs.html">Home</a></li>
   <li class="menu"><a href="postajob.php">Post a Job</a></li>
     <li class="menu" ><a href="findajob.html">Find a Job</a></li>
     <li class="menu"><a href="signin.html">SignIn</a></li>
   <li class="menu"><a href="signup.php">SignUp</a></li>
   <li class="menu"><a href="user.php">User Account</a></li>
   <li class="menu"><a href="category.html">Category</a></li>
   <li class="menu"><a href="submitCV.php">Submit CV</a></li>
   <li class="menu"><a href="about.html">About</a></li>
     <li class="menu" ><a href="contactus.html">Contact Us</a></li> 
     </ul>

     </nav>
  </div>
</header>


<center>
<h3>Submit CV</h3>

<form action="#" onsubmit="return checkPassword()">
First Name: <br/>
<input type="text" name="firstname" placeholder="First Name" required><br/></br>
Last Name: <br/>
<input type="text" name="lastname" placeholder="Last Name" required><br/></br>
Gender:<br/>
<input type="radio" name="gender" checked>Male
<input type="radio" name="gender">Female<br/><br/>
Mobile Number:<br/>
<input type="phone" name="mobile" placeholder="0123456789" pattern="[0-9]{10}" required><br/></br>
Email:
<input type="email" name="email" placeholder="example@gmail.com" pattern="[a-z0-9.%+-]+@[a-z0-9.]+\.[a-z]{2,3}" required><br/><br/>
Address:<br/>
<textarea name="address" rows="8" cols="50" required></textarea><br/><br/>
Date of birth:<br/>
<input type="date" name="date" required><br/><br/>
Education Qualification:<br/>
<textarea name="EQ" rows="8" cols="50" placeholder="A/L results, O/L results,etc." required></textarea><br/><br/>
Working Experince:<br/>
<textarea name="WE" rows="8" cols="50" required></textarea><br/><br/>
<input type="checkbox" id="checkbox" onclick="enableButton()">Accept privacy policy and terms.<br/><br/>
<input type="button" id="submitBtn" value="submit" disabled>
</form>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<!---footer section; do not edit-->
<footer>
        <div class="main-content">
          <div class="left box">
            <h2>About us</h2>
      <div class="content">
      <p>You can post jobs for free here with DreamJob.lk<br>Candidates submit your Cv and get contacted by Employers<br>Search jobs all over the Sri Lanka<br>here</p>
      <div class="social">
              <a href="https://facebook.com"><span class="fab fa-facebook-f"></span></a>
              <a href="https://twitter.com"><span class="fab fa-twitter"></span></a>
              <a href="https://instagram.com"><span class="fab fa-instagram"></span></a>
              <a href="https://youtube.com"><span class="fab fa-youtube"></span></a>
            </div>
      </div>
        </div>
 <div class="center box">
   <h3> Contact Us </h3>
   <div class="content"
          <div class="website">
      <span class="text">DreamJob.lk</span><br>
      </div>
      <div class="place">
              <br><span class="fas fa-map-marker-alt"></span>
              <span class="text">Malabe,Sri Lanka</span>
            </div>
      <div class="hotline">
              <span class="fas fa-phone-alt"></span>
              <span class="text">Hotline:(011)7894561</span>
            </div>
              <div class="email">
              <span class="fas fa-envelope"></span>
              <span class="text">Email:info@DreamJob.lk</span>
            </div>
      </div>
</div>
      <div class="bottom">
        <center>
          <span class="credit">DreamJob.lk 2021-All rights reserved-Powered by PROGECT GROUP 02 of Lab group 05 </span>
          <span class="far fa-copyright"></span><span> 2021 All rights reserved.</span>
        </center>
      </div>
    </div>    
    </footer>
</body>
</html>