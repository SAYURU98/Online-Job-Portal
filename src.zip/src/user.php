<?php
include_once('db.php');
$query="select * from useracc";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <script src="https://kit.fontawesome.com/350c24570c.js" crossorigin="anonymous"></script>
	<title>Professional profile</title>
	<link rel="stylesheet" href="styles/styles.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/user.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>
<body>
<header>
  <div class="container1">
     <h1 style="font-size:40px; font-family:courier,monospace; text-align:left; padding-left:45px; float:left;">DreamJobs <i class="fas fa-anchor"></i></h1>

     <nav>

     <ul class="menu">
     <li class="menu"><a href="DreamJobs.html">Home</a></li>
	 <li class="menu"><a href="postajob.php">Post a Job</a></li>
     <li class="menu" ><a href="findajob.html">Find a Job</a></li>
     <li class="menu"><a href="signin.html">SignIn</a></li>
	 <li class="menu"><a href="signup.php">SignUp</a></li>
	 <li class="menu"><a href="user.php">User Account</a></li>
	 <li class="menu"><a href="category.html">Category</a></li>
	 <li class="menu"><a href="submitCV.php">Submit CV</a></li>
	 <li class="menu"><a href="about.html">About</a></li>
     <li class="menu" ><a href="contactus.html">Contact Us</a></li> 
     </ul>

     </nav>
  </div>
</header>
 <div class="row">
        <div class="col-md-6">
            <img src=https://toppng.com/uploads/preview/file-svg-profile-icon-vector-11562942678pprjdh47a8.png>
            <h4>Alex William</h4>
            <p>UI Developer</p>
        </div>
        <div class="col-md-6" >
            
            <?php
                        while($rows=mysqli_fetch_assoc($result))
                        {
                    ?>
                    <div class="data">
                        <h4>Email</h4>
                        <p><?php echo $rows['email'];?>
                    </div>
                    <div class="data">
                        <h4>First Name</h4>
                        <p><?php echo $rows['firstname'];?>
                    </div>
                    <div class="data">
                        <h4>Last Name</h4>
                        <p><?php echo $rows['lastname'];?>
                    </div>
                    <div class="data">
                        <h4>Phone Number</h4>
                         <p><?php echo $rows['phonenumber'];?>
                    </div>
                    <div class="data">
                        <h4>Birthday</h4>
                         <p><?php echo $rows['birthday'];?>
                    </div>
                    <div class="data">
                        <h4>District</h4>
                         <p><?php echo $rows['district'];?>
                    </div>
                    <div class="data">
                        <h4>Educational Qualification</h4>
                         <p><?php echo $rows['educationalq'];?>
                    </div>
                    <?php
                        }
                    ?>
                    <div class="btn">
                        <a href="useredit.php" button type="submit"  class="btn btn-primary">Submit</a></button><br>
                        <button type="submit" class="btn btn-primary" >Log out</button>
                    </div>
        </div>
    </div>


	
<footer>
        <div class="main-content">
          <div class="left box">
            <h2>About us</h2>
			<div class="content">
			<p>You can post jobs for free here with DreamJob.lk<br>Candidates submit your Cv and get contacted by Employers<br>Search jobs all over the Sri Lanka<br>here</p>
			<div class="social">
              <a href="https://facebook.com"><span class="fab fa-facebook-f"></span></a>
              <a href="https://twitter.com"><span class="fab fa-twitter"></span></a>
              <a href="https://instagram.com"><span class="fab fa-instagram"></span></a>
              <a href="https://youtube.com"><span class="fab fa-youtube"></span></a>
            </div>
			</div>
        </div>
 <div class="center box">
	 <h3> Contact Us </h3>
	 <div class="content"
          <div class="website">
		  <span class="text">DreamJob.lk</span><br>
		  </div>
		  <div class="place">
              <br><span class="fas fa-map-marker-alt"></span>
              <span class="text">Malabe,Sri Lanka</span>
            </div>
			<div class="hotline">
              <span class="fas fa-phone-alt"></span>
              <span class="text">Hotline:(011)7894561</span>
            </div>
              <div class="email">
              <span class="fas fa-envelope"></span>
              <span class="text">Email:info@DreamJob.lk</span>
            </div>
			</div>
</div>
		  <div class="bottom">
        <center>
          <span class="credit">DreamJob.lk 2021-All rights reserved-Powered by PROGECT GROUP 02 of Lab group 05 </span>
          <span class="far fa-copyright"></span><span> 2021 All rights reserved.</span>
        </center>
      </div>
		</div>		
	  </footer>
</body>
</html>