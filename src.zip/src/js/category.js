function loadData(name){
	if(name=="btn1"){
		document.getElementById("para").innerHTML = "Ampara,Anuradhapura,Badulla,Batticaloa,Colombo,Galle,Gampaha";
		
	}
	else if (name=="btn2") {
		document.getElementById("para").innerHTML = "Accounting,Cashier,Hospitality,Hotel,Engineering,Software,Grapic designing";
		
	}
	else if (name=="btn3") {
		document.getElementById("para").innerHTML = "Remite,On site,Local,Foreign,On shop";
	}
	
	else{
		alert ("Invalid!");
	}
	
} 